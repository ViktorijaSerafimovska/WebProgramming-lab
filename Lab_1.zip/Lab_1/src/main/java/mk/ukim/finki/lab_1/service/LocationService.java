package mk.ukim.finki.lab_1.service;

import mk.ukim.finki.lab_1.model.Location;

import java.util.List;
import java.util.List;

public interface LocationService {
    List<Location> findAll();
}
