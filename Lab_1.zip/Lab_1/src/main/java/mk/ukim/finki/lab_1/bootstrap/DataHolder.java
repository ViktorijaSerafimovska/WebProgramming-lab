package mk.ukim.finki.lab_1.bootstrap;


import jakarta.annotation.PostConstruct;
import mk.ukim.finki.lab_1.model.Event;
import mk.ukim.finki.lab_1.model.Location;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Event> events = new ArrayList<>();
    public static List<Location> locations = new ArrayList<>();
    @PostConstruct
    public void init() {

        locations.add(new Location(1L, "Partizanska", "Partizanska Street, Gostivar", "200", "Main street location"));
        locations.add(new Location(2L, "Ljubljanska", "Skopska Street, Gostivar", "150", "Popular area for events"));
        locations.add(new Location(3L, "Teodosij Gologanov", "Teodosij Gologanov, Gostivar", "500", "Large medical complex"));
        locations.add(new Location(4L, "Bukova", "Bukova Street, Gostivar", "100", "Quiet neighborhood spot"));
        locations.add(new Location(5L, "Shopping Center", "Shopping Center, Gostivar", "300", "Shopping and entertainment area"));

        events.add(new Event("Concert", "Live music concert", 4.5, locations.get(0)));
        events.add(new Event("Art Exhibition", "Modern art showcase", 4.0, locations.get(1)));
        events.add(new Event("Tech Conference", "Technology trends and insights", 4.8, locations.get(2)));
        events.add(new Event("Film Festival", "Showcasing independent films", 4.2, locations.get(3)));
        events.add(new Event("Food Fair", "Taste of various cuisines", 4.6, locations.get(4)));
        events.add(new Event("Charity Run", "Running for a good cause", 4.3, locations.get(0)));
        events.add(new Event("Book Signing", "Meet your favorite authors", 4.4, locations.get(1)));
        events.add(new Event("Theater Play", "Classic drama performance", 4.7, locations.get(2)));
        events.add(new Event("Stand-up Comedy", "A night of laughter", 4.1, locations.get(3)));
        events.add(new Event("Dance Party", "Join us for a night of dancing", 4.5, locations.get(4)));
    }
}
