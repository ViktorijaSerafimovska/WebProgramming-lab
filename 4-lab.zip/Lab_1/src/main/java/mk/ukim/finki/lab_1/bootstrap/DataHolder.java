/*package mk.ukim.finki.lab_1.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.lab_1.model.Event;
import mk.ukim.finki.lab_1.model.Location;
import mk.ukim.finki.lab_1.repository.EventRepository;
import mk.ukim.finki.lab_1.repository.LocationRepository;
import org.springframework.stereotype.Component;

@Component
public class DataHolder {

    private final EventRepository eventRepository;
    private final LocationRepository locationRepository;

    public DataHolder(EventRepository eventRepository, LocationRepository locationRepository) {
        this.eventRepository = eventRepository;
        this.locationRepository = locationRepository;
    }

    @PostConstruct
    public void init() {
        Location loc1 = new Location( "Partizanska", "Partizanska Street, Gostivar", "200", "Main street location");
        Location loc2 = new Location("Ljubljanska", "Skopska Street, Gostivar", "150", "Popular area for events");
        Location loc3 = new Location("Teodosij Gologanov", "Teodosij Gologanov, Gostivar", "500", "Large medical complex");
        Location loc4 = new Location("Bukova", "Bukova Street, Gostivar", "100", "Quiet neighborhood spot");
        Location loc5 = new Location( "Shopping Center", "Shopping Center, Gostivar", "300", "Shopping and entertainment area");

        locationRepository.save(loc1);
        locationRepository.save(loc2);
        locationRepository.save(loc3);
        locationRepository.save(loc4);
        locationRepository.save(loc5);

        eventRepository.save(new Event("Concert", "Live music concert", 4.5, loc1));
        eventRepository.save(new Event("Art Exhibition", "Modern art showcase", 4.0, loc2));
        eventRepository.save(new Event("Tech Conference", "Technology trends and insights", 4.8, loc3));
        eventRepository.save(new Event("Film Festival", "Showcasing independent films", 4.2, loc4));
        eventRepository.save(new Event("Food Fair", "Taste of various cuisines", 4.6, loc5));
        eventRepository.save(new Event("Charity Run", "Running for a good cause", 4.3, loc1));
        eventRepository.save(new Event("Book Signing", "Meet your favorite authors", 4.4, loc2));
        eventRepository.save(new Event("Theater Play", "Classic drama performance", 4.7, loc3));
        eventRepository.save(new Event("Stand-up Comedy", "A night of laughter", 4.1, loc4));
        eventRepository.save(new Event("Dance Party", "Join us for a night of dancing", 4.5, loc5));
    }
}
*/
package mk.ukim.finki.lab_1.bootstrap;


import jakarta.annotation.PostConstruct;
import mk.ukim.finki.lab_1.model.Event;
import mk.ukim.finki.lab_1.model.Location;
import mk.ukim.finki.lab_1.repository.JPA.EventRepositor;
import mk.ukim.finki.lab_1.repository.JPA.LocationRepositor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Event> events = new ArrayList<>();
    public static List<Location> locations = new ArrayList<>();

    private final EventRepositor eventRepository;
    private final LocationRepositor locationRepository;



    public DataHolder(EventRepositor eventRepository, LocationRepositor locationRepository) {
        this.eventRepository = eventRepository;
        this.locationRepository = locationRepository;
    }

    @PostConstruct
    public void init() {
        if (locationRepository.count() == 0) {
            Location location1 = new Location("Partizanska", "Partizanska Street, Gostivar", "200", "Main location");
            Location location2 = new Location("Ljubljanska", "Skopska Street, Gostivar", "150", "Popular area");
            Location location3 = (new Location("Teodosij Gologanov", "Teodosij Gologanov, Gostivar", "500", "Large medical complex"));
            Location location4 = (new Location( "Bukova", "Bukova Street, Gostivar", "100", "Quiet neighborhood spot"));
            Location location5 = (new Location("Shopping Center", "Shopping Center, Gostivar", "300", "Shopping and entertainment area"));

            locationRepository.save(location1);
            locationRepository.save(location2);
            locationRepository.save(location3);
            locationRepository.save(location4);
            locationRepository.save(location5);

            eventRepository.save(new Event("Concert", "Live music concert", 4.5, location1));
            eventRepository.save(new Event("Art Exhibition", "Modern art showcase", 4.0, location2));
            eventRepository.save(new Event("Tech Conference", "Technology trends and insights", 4.8, location1));
            eventRepository.save(new Event("Film Festival", "Showcasing independent films", 4.2, location2));
            eventRepository.save(new Event("Food Fair", "Taste of various cuisines", 4.6, location1));
            eventRepository.save(new Event("Charity Run", "Running for a good cause", 4.3, location2));
            eventRepository.save(new Event("Book Signing", "Meet your favorite authors", 4.4, location1));
            eventRepository.save(new Event("Theater Play", "Classic drama performance", 4.7, location2));
            eventRepository.save(new Event("Stand-up Comedy", "A night of laughter", 4.1, location1));
            eventRepository.save(new Event("Dance Party", "Join us for a night of dancing", 4.5, location2));

        }
/*
        locations.add(new Location(1L, "Partizanska", "Partizanska Street, Gostivar", "200", "Main street location"));
        locations.add(new Location(2L, "Ljubljanska", "Skopska Street, Gostivar", "150", "Popular area for events"));
        locations.add(new Location(3L, "Teodosij Gologanov", "Teodosij Gologanov, Gostivar", "500", "Large medical complex"));
        locations.add(new Location(4L, "Bukova", "Bukova Street, Gostivar", "100", "Quiet neighborhood spot"));
        locations.add(new Location(5L, "Shopping Center", "Shopping Center, Gostivar", "300", "Shopping and entertainment area"));


        events.add(new Event("Concert", "Live music concert", 4.5, locations.get(0)));
        events.add(new Event("Art Exhibition", "Modern art showcase", 4.0, locations.get(1)));
        events.add(new Event("Tech Conference", "Technology trends and insights", 4.8, locations.get(2)));
        events.add(new Event("Film Festival", "Showcasing independent films", 4.2, locations.get(3)));
        events.add(new Event("Food Fair", "Taste of various cuisines", 4.6, locations.get(4)));
        events.add(new Event("Charity Run", "Running for a good cause", 4.3, locations.get(0)));
        events.add(new Event("Book Signing", "Meet your favorite authors", 4.4, locations.get(1)));
        events.add(new Event("Theater Play", "Classic drama performance", 4.7, locations.get(2)));
        events.add(new Event("Stand-up Comedy", "A night of laughter", 4.1, locations.get(3)));
        events.add(new Event("Dance Party", "Join us for a night of dancing", 4.5, locations.get(4)));
    */


    }



}
